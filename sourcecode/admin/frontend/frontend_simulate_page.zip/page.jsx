'use client'

import { useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { auth } from '@/libs/firebase'
import { signInWithCustomToken } from 'firebase/auth'
import { apiInstance } from '@/utils/ApiInstance'
import CircularProgress from '@mui/material/CircularProgress'
import Typography from '@mui/material/Typography'
import Box from '@mui/material/Box'

const SimulateUserPage = () => {
  const [error, setError] = useState('')
  const [status, setStatus] = useState('Initializing simulation...')
  const searchParams = useSearchParams()
  const uid = searchParams.get('uid')
  const router = useRouter()

  useEffect(() => {
    const startSimulation = async () => {
      if (!uid) {
        setError('User UID is missing.')
        return
      }

      try {
        setStatus('Fetching custom token...')
        // Call backend to get custom token
        const response = await apiInstance.get(`/admin/users/simulate/${uid}`)
        
        // Since apiInstance has an interceptor that returns response.data,
        // response might already be the body, or it might be the axios response object.
        const responseBody = response.data !== undefined ? response.data : response;
        const responseStatus = response.status !== undefined ? response.status : responseBody.status;

        if (!responseStatus || responseStatus === false) {
          throw new Error(responseBody.message || 'Failed to generate custom token')
        }

        const customToken = responseBody.data?.customToken || responseBody.customToken;
        if (!customToken) {
           throw new Error('Custom token is missing from the response.');
        }

        setStatus('Authenticating with Firebase...')
        // Sign in with custom token using the existing Firebase App
        // NOTE: This will log the admin out of the admin panel in this browser session
        await signInWithCustomToken(auth, customToken)

        setStatus('Fetching user profile...')
        // Fetch user profile from Firebase to populate GetStorage
        const idToken = await auth.currentUser.getIdToken()
        
        // Call the app's profile endpoint
        const userDetailsRes = await apiInstance.get(`/admin/users/listRegisteredUsers?userId=${uid}`)
        const userDetailsBody = userDetailsRes.data !== undefined ? userDetailsRes.data : userDetailsRes;
        
        // Data could be directly in userDetailsBody or in userDetailsBody.data
        let userData = null;
        if (Array.isArray(userDetailsBody)) {
            userData = userDetailsBody[0];
        } else if (Array.isArray(userDetailsBody.data)) {
            userData = userDetailsBody.data[0];
        } else {
            userData = userDetailsBody.data || userDetailsBody;
        }

        setStatus('Setting up app state...')
        // Construct the GetStorage keys exactly as Flutter expects them
        // In Flutter Web, GetStorage saves a JSON string under the key "GetStorage" in localStorage
        // However, Flutter's `localStorage.read("isLogin")` sometimes maps to individual keys 
        // depending on how GetStorage is initialized. Wait, GetStorage default container is "GetStorage".
        // Let's set both the specific keys and the GetStorage object to be safe.
        
        const storageObj = {
          isLogin: true,
          loginUserFirebaseId: uid,
          loginUserId: userData?._id || "",
          isFillProfile: true, // Bypass profile creation
          isListener: userData?.isListener || false,
          isGuestMode: false,
          loginUserName: userData?.fullName || "",
          loginUserEmail: userData?.email || "",
          loginUserProfilePic: userData?.profilePic || "",
        }

        // GetStorage writes individual keys if it's not a named container? No, it writes to a single JSON.
        // We will set individual items because sometimes window.localStorage is used directly, or GetStorage parses the JSON.
        // Let's set individual items first (some Flutter plugins use direct localStorage)
        localStorage.setItem("isLogin", true)
        localStorage.setItem("loginUserFirebaseId", uid)
        localStorage.setItem("isFillProfile", true)

        // And construct the GetStorage object
        const currentStorage = JSON.parse(localStorage.getItem('GetStorage') || '{}')
        const newStorage = { ...currentStorage, ...storageObj }
        localStorage.setItem('GetStorage', JSON.stringify(newStorage))

        setStatus('Redirecting to app...')
        // Redirect to the Flutter Web app
        window.location.href = '/app/'

      } catch (err) {
        console.error('Simulation error:', err)
        setError(err.message || 'An error occurred during simulation.')
      }
    }

    startSimulation()
  }, [uid, router])

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100vh',
        backgroundColor: '#f5f5f5'
      }}
    >
      {error ? (
        <Typography color="error" variant="h6">{error}</Typography>
      ) : (
        <>
          <CircularProgress size={60} sx={{ mb: 4 }} />
          <Typography variant="h5" color="textPrimary">
            {status}
          </Typography>
          <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
            You will be redirected shortly...
          </Typography>
        </>
      )}
    </Box>
  )
}

export default SimulateUserPage
